import socket 
import time
import ipaddress
import threading
import sys

lock = threading.Lock()

def validIP(address):
    try:
        ipaddress.ip_address(address)
        return True
    except ValueError:
        return False
    
def connectSocket(address):
    lock.acquire_lock()
    global num
    try:
        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client_socket.connect((address, 8082)) 
    except:
        print("Connection Failed")
        lock.release_lock()
        return False
    lock.release_lock()
    ip_address = client_socket.getsockname()[0]
    

    running = True
    while running: 
        client_socket.send(b'Hello, I am ' + str(ip_address).encode('utf-8') + b' and my number is ' + str(num).encode('utf-8'))
        time.sleep(1)
    
    client_socket.close()

num = -1

if len(sys.argv) > 1:
    numIn = sys.argv[1]
else:
    print("Missing arguments")
    exit()

if(numIn != None and numIn.isnumeric() and int(numIn)>1):
   num = int(numIn)
else:
   print("Invalid number")
   exit()

cont = True
while(cont):
   lock.acquire_lock()
   ipIn = input("Enter a IPv4 address, or type 'exit' to stop: ")
   lock.release_lock()
   print(ipIn)
   if (ipIn == 'exit'):
      cont = False
      break
   else:
        if(validIP(ipIn)):
          thread = threading.Thread(target = connectSocket, args = (ipIn,))
          thread.start()
        else: print("Invalid IP")
         
      


   

